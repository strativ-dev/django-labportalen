# django-labportalen
A convenient library to communicate with labportalen
